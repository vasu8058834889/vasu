<a href="https://www.youtube.com/watch?v=fl0ow-nD8FM&list=PLxqBkZuBynVQEvXfJpq3smfuKq3AiNW-N&index=20"><h1 style="font-size:250%; font-family:cursive; color:#ff6666;"><b>Link YouTube Video - Topic Modeling with BERTopic | arxiv-abstract dataset</b></h1></a>

[![IMAGE ALT TEXT](https://imgur.com/XKntgbj.png)](https://www.youtube.com/watch?v=fl0ow-nD8FM&list=PLxqBkZuBynVQEvXfJpq3smfuKq3AiNW-N&index=20)


--------------

### Connect with me here..

- 🐦 TWITTER: https://twitter.com/rohanpaul_ai
- ​👨‍🔧​ KAGGLE: https://www.kaggle.com/paulrohan2020
- 👨🏻‍💼 LINKEDIN: https://www.linkedin.com/in/rohan-paul-b27285129/
- 👨‍💻 GITHUB: https://github.com/rohan-paul
- 🤖 Substack : https://rohanpaul.substack.com/
- 🧑‍🦰 FACEBOOK: https://www.facebook.com/rohanpaulai
- 📸 INSTAGRAM: https://www.instagram.com/rohan_paul_2020/