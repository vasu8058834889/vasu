<a href="https://www.youtube.com/watch?v=6X0xfXMKCjM&list=PLxqBkZuBynVQEvXfJpq3smfuKq3AiNW-N&index=29&ab_channel=Rohan-Paul-AI"><h1 style="font-size:250%; font-family:cursive; color:#ff6666;"><b>Link YouTube Video - Roberta-Large Named Entity Recognizition on Kaggle NLP Competition with PyTorch</b></h1></a>

[![IMAGE ALT TEXT](https://imgur.com/W6xP1PF.png)](https://www.youtube.com/watch?v=6X0xfXMKCjM&list=PLxqBkZuBynVQEvXfJpq3smfuKq3AiNW-N&index=29&ab_channel=Rohan-Paul-AI "")

---------------------

### [Kaggle - Feedback Prize - Evaluating Student Writing](https://www.kaggle.com/competitions/feedback-prize-2021)

### You can run the Notebook `Pytorch-Roberta_Large.ipynb`  either Locally or in Kaggle - Just modify the 'ROOT_DIR' variable to properly refer to the dataset

--------------

### Connect with me here..

- 🐦 TWITTER: https://twitter.com/rohanpaul_ai
- ​👨‍🔧​ KAGGLE: https://www.kaggle.com/paulrohan2020
- 👨🏻‍💼 LINKEDIN: https://www.linkedin.com/in/rohan-paul-b27285129/
- 👨‍💻 GITHUB: https://github.com/rohan-paul
- 🤖 Substack : https://rohanpaul.substack.com/
- 🧑‍🦰 FACEBOOK: https://www.facebook.com/rohanpaulai
- 📸 INSTAGRAM: https://www.instagram.com/rohan_paul_2020/