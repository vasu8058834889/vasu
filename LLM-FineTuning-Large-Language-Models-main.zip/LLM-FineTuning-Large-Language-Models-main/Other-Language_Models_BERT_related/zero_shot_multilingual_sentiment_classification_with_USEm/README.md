<a href="https://www.youtube.com/watch?v=tvdIF1FU7fg&list=PLxqBkZuBynVQEvXfJpq3smfuKq3AiNW-N&index=24"><h1 style="font-size:250%; font-family:cursive; color:#ff6666;"><b>Zero Shot Multilingual Sentiment Classification with PyTorch Lightning | NLP </b></h1></a>

[![IMAGE ALT TEXT](https://imgur.com/wqKxWJj.png)](https://www.youtube.com/watch?v=tvdIF1FU7fg&list=PLxqBkZuBynVQEvXfJpq3smfuKq3AiNW-N&index=24)

---

--------------

### Connect with me here..

- 🐦 TWITTER: https://twitter.com/rohanpaul_ai
- ​👨‍🔧​ KAGGLE: https://www.kaggle.com/paulrohan2020
- 👨🏻‍💼 LINKEDIN: https://www.linkedin.com/in/rohan-paul-b27285129/
- 👨‍💻 GITHUB: https://github.com/rohan-paul
- 🤖 Substack : https://rohanpaul.substack.com/
- 🧑‍🦰 FACEBOOK: https://www.facebook.com/rohanpaulai
- 📸 INSTAGRAM: https://www.instagram.com/rohan_paul_2020/