## Transformer Encoder (with Scaled Dot Product) from Scratch

# [Link to my Youtube Video Explaining this whole Notebook](https://www.youtube.com/watch?v=CHFiTTPeyUw&list=PLxqBkZuBynVTn2lkHNAcw6lgm1MD5QiMK&index=9)

[![Imgur](https://imgur.com/1vIXcXF.png)](https://www.youtube.com/watch?v=CHFiTTPeyUw&list=PLxqBkZuBynVTn2lkHNAcw6lgm1MD5QiMK&index=9)

------------------------------

### Connect with me here..

- 🐦 TWITTER: https://twitter.com/rohanpaul_ai
- ​👨‍🔧​ KAGGLE: https://www.kaggle.com/paulrohan2020
- 👨🏻‍💼 LINKEDIN: https://www.linkedin.com/in/rohan-paul-b27285129/
- 👨‍💻 GITHUB: https://github.com/rohan-paul
- 🤖 Substack : https://rohanpaul.substack.com/
- 🧑‍🦰 FACEBOOK: https://www.facebook.com/rohanpaulai
- 📸 INSTAGRAM: https://www.instagram.com/rohan_paul_2020/